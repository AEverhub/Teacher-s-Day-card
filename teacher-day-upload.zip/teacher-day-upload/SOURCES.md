# 圖片來源

本網站使用的科技感背景素材來自 Unsplash 圖片搜尋結果，僅作為教師節數位卡片的裝飾背景使用。

- `assets/quantum-wave.jpg`：Unsplash，https://unsplash.com/
- `assets/purple-light-trails.jpg`：Unsplash，https://unsplash.com/

頁面主視覺圖片旁與頁尾均保留來源連結。
